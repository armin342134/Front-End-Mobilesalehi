import React from "react";
import BrandProduct from "../components/ProductsComponents/BrandProduct";

export default function UsedPhones() {
  return (
    <div>
      <div>
        <BrandProduct brandName={"کارکرده"} />
      </div>
    </div>
  );
}
