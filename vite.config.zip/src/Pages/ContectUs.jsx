import React from "react";

export default function ContectUs() {
  return (
    <div className="mt-5 border rounded-3 p-3">
      <div className=" mt-3 ">
        <h1 className="">ارتباط باما</h1>
      </div>
      <div>
        <div className="mt-5">
          <h3>آدرس فروشگاه : سهند فاز1 محله3 مجتمع تجاری نفیس</h3>
        </div>
        <div className="mt-5">
          <h3>ایمیل : examel@gmail.com</h3>
          <h3>تلفن : 09910450537</h3>
        </div>
        <div className="mt-5">
          <h3>
            ساعات پاسخگویی تلفنی: شنبه تا چهارشنبه 9 الی 17 (پنج شنبه 9 الی 13)
          </h3>
        </div>
      </div>
    </div>
  );
}
