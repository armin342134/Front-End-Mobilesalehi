import React from "react";
import BrandProduct from "../BrandProduct";

export default function Macbook() {
  return <BrandProduct brandName={"Mackbook"} />;
}
