import React from "react";
import BrandProduct from "../BrandProduct";

export default function HpProducts() {
  return <BrandProduct brandName={"Hp"} />;
}
