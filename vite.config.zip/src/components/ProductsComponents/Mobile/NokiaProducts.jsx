import React from "react";
import BrandProduct from "../BrandProduct";

export default function NokiaProducts() {
  return <BrandProduct brandName={"Nokia"} />;
}
