import React from "react";
import BrandProduct from "../BrandProduct";

export default function XiaomiProducts() {
  return <BrandProduct brandName={"Xiaomi"} />;
}
