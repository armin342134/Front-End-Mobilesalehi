import BrandProduct from "../BrandProduct";

export default function SamsungProduct() {
  return <BrandProduct brandName={"Samsung"} />;
}
